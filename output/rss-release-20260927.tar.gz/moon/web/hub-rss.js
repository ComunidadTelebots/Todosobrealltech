(() => {
  if (document.getElementById('personal-rss-open')) return;
  const style = document.createElement('style'); style.textContent = '#personal-rss-open{position:fixed;right:14px;bottom:78px;z-index:9000;background:#0891b2;color:white;border:0;border-radius:24px;padding:12px 18px;font-weight:bold}#personal-rss-dialog{position:fixed;inset:6vh 4vw;z-index:10000;overflow:auto;background:var(--tg-theme-bg-color,#fff);color:var(--tg-theme-text-color,#111);border:1px solid #888;border-radius:18px;padding:20px;box-shadow:0 12px 60px #0006}#personal-rss-dialog button,#personal-rss-dialog input,#personal-rss-dialog select{font:inherit;padding:9px;margin:4px;border:1px solid #888;border-radius:8px;background:transparent;color:inherit;max-width:100%;box-sizing:border-box}#personal-rss-dialog input{width:95%}#personal-rss-dialog article{border:1px solid #8885;padding:12px;border-radius:10px;margin:8px 0;overflow-wrap:anywhere}#personal-rss-dialog a{color:#0891b2}'; document.head.append(style);
  const launch=document.createElement('button');launch.id='personal-rss-open';launch.textContent='Mis RSS';document.body.append(launch);
  const dialog=document.createElement('section');dialog.id='personal-rss-dialog';dialog.hidden=true;dialog.setAttribute('role','dialog');dialog.setAttribute('aria-label','Mis RSS');dialog.setAttribute('aria-modal','true');dialog.tabIndex=-1;document.body.append(dialog);
  let busy=false, channels=[], target="me";
  const el=(tag,text,parent=dialog)=>{const n=document.createElement(tag);if(text)n.textContent=text;parent.append(n);return n;};
  async function load(body={}) {
    if(busy)return;busy=true;
    for(const b of dialog.querySelectorAll('button'))b.disabled=true;
    try {
      const r=await fetch(target==='me'?'/api/public/rss/mine':'/api/public/rss/channel',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({...body,chat_id:target,initData:window.Telegram?.WebApp?.initData||''})});
      const data=await r.json();if(!r.ok||!data.ok)throw new Error(data.error||'RSS no disponible');render(data);
    }catch(error){const p=el('p',error.message);p.setAttribute('role','alert');}
    finally{busy=false;for(const b of dialog.querySelectorAll('button'))b.disabled=b.dataset.disabled==='true';}
  }
  function button(label,action,parent=dialog){const b=el('button',label,parent);b.type='button';b.onclick=action;return b;}
  function header(){
    button('Cerrar',()=>{dialog.hidden=true;launch.focus();});el('h2','RSS · Suscripciones y catálogo · Beta');
    const label=el('label','Enviar novedades a ');const select=el('select',null,label);select.setAttribute('aria-label','Destino RSS');
    const own=el('option','Mi chat privado',select);own.value='me';
    for(const channel of channels){const option=el('option',channel.name,select);option.value=channel.id;}
    select.value=target;select.onchange=()=>{if(!busy){target=select.value;load();}};
  }
  function render(data){
    dialog.replaceChildren();header();
    el('p','Recibe novedades por privado. Las fuentes nuevas se guardan pausadas; actívalas para empezar.');
    const q=data.quota;if(q){el('p',`Cupo usado hoy: ${q.used} / ${q.limit} noticias · reinicio diario UTC.`);
    el('p',q.membership==='member'?'Pertenencia al canal verificada: puedes superar el cupo.':q.membership==='unavailable'?'No se pudo verificar tu pertenencia al canal.':`Para superar ${q.limit} noticias al día, únete a ${q.channel}.`);
    if(q.blocked)el('p','Entregas pausadas por el límite diario. Únete al canal y comprueba tu suscripción.');
    if(q.delivery_uncertain)el('p','Entrega pendiente de revisión por el administrador. No se reintentará automáticamente para evitar duplicados.');
    const a=el('a','Abrir @TodoSobreAllTech');a.href='https://t.me/TodoSobreAllTech';a.target='_blank';a.rel='noopener noreferrer';
    button('Comprobar suscripción',()=>load({action:'verify_membership'}));}
    el('h3','Explorar RSS por categoría');const search=el('input');search.placeholder='Buscar fuente o tema';search.setAttribute('aria-label','Buscar RSS');const category=el('select');category.setAttribute('aria-label','Categoría RSS');const all=el('option','Todas las categorías',category);all.value='all';
    for(const name of [...new Set(data.catalog.map(i=>i.category))].sort()){const option=el('option',name,category);option.value=name;}
    const catalog=el('div');function showCatalog(){catalog.replaceChildren();for(const name of [...new Set(data.catalog.map(i=>i.category))].sort()){
      if(category.value!=='all'&&category.value!==name)continue;
      const items=data.catalog.filter(i=>i.category===name&&`${i.title} ${i.category}`.toLowerCase().includes(search.value.toLowerCase()));if(!items.length)continue;el('h4',name,catalog);
      for(const item of items){const row=el('article',null,catalog);el('b',item.title,row);el('p',(item.language||'').toUpperCase(),row);const exists=data.feeds.some(f=>f.url===item.url);const b=button(exists?'Ya añadido':'Suscribirme',()=>load({action:'add',url:item.url,title:item.title}),row);b.disabled=exists;b.dataset.disabled=String(exists);}}
    }search.oninput=showCatalog;category.onchange=showCatalog;showCatalog();
    const form=el('form');const title=el('input',null,form);title.placeholder='Nombre de la fuente';title.setAttribute('aria-label','Nombre de la fuente');title.maxLength=120;
    const url=el('input',null,form);url.type='url';url.required=true;url.maxLength=2000;url.placeholder='https://ejemplo.com/feed.xml';url.setAttribute('aria-label','URL RSS');const submit=el('button','Añadir mi RSS',form);submit.type='submit';form.onsubmit=e=>{e.preventDefault();load({action:'add',url:url.value.trim(),title:title.value.trim()});};
    el('h3',`Mis fuentes (${data.feeds.length}/${data.limit})`);
    if(!data.feeds.length)el('p','Todavía no tienes suscripciones. Selecciona una fuente o añade su URL.');
    for(const feed of data.feeds){const row=el('article');el('b',feed.title||'Fuente RSS',row);el('p',feed.url,row);el('p',`${feed.enabled?'Activa':'Pausada'} · ${feed.published_count||0} entregas · ${feed.error_count||0} errores`,row);button(feed.enabled?'Pausar':'Activar',()=>load({action:'toggle',feed_id:feed.id,enabled:!feed.enabled}),row);button('Eliminar',()=>{if(confirm('¿Eliminar esta suscripción?'))load({action:'delete',feed_id:feed.id});},row);}
    button('Actualizar',()=>load());
  }
  launch.onclick=async()=>{dialog.hidden=false;dialog.focus();dialog.replaceChildren();header();try{const r=await fetch('/api/public/rss/destinations',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({initData:window.Telegram?.WebApp?.initData||''})});const data=await r.json();channels=data.channels||[];}catch{channels=[];}dialog.replaceChildren();header();load();};
  dialog.addEventListener('keydown',e=>{if(e.key==='Escape'){dialog.hidden=true;launch.focus();}if(e.key==='Tab'){const nodes=[...dialog.querySelectorAll('button:not(:disabled),input,a,select')];const first=nodes[0],last=nodes[nodes.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus();}}});
})();
