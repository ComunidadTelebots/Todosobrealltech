"""Curated public feed directory. No subscriptions are created automatically."""
CATALOG = [
    {"id":"alltech","category":"Tecnología","title":"TodoSobreAllTech · Noticias","url":"https://api.todosobreall.tech/noticias/rss","language":"es"},
    {"id":"rtve-news","category":"Actualidad","title":"RTVE · Noticias","url":"https://www.rtve.es/rss/temas_noticias.xml","language":"es"},
    {"id":"rtve-world","category":"Internacional","title":"RTVE · Mundo","url":"https://www.rtve.es/rss/temas_mundo.xml","language":"es"},
    {"id":"rtve-sports","category":"Deportes","title":"RTVE · Deportes","url":"https://www.rtve.es/rss/temas_deportes.xml","language":"es"},
    {"id":"rtve-science","category":"Ciencia","title":"RTVE · Ciencia y tecnología","url":"https://www.rtve.es/rss/temas_ciencia-tecnologia.xml","language":"es"},
    {"id":"rtve-culture","category":"Cultura","title":"RTVE · Cultura","url":"https://www.rtve.es/rss/temas_cultura.xml","language":"es"},
    {"id":"rtve-economy","category":"Economía","title":"RTVE · Economía","url":"https://www.rtve.es/rss/temas_economia.xml","language":"es"},
    {"id":"rtve-weather","category":"Medio ambiente y tiempo","title":"RTVE · El tiempo","url":"https://www.rtve.es/rss/temas_tiempo.xml","language":"es"},
    {"id":"nasa-cneos","category":"Espacio","title":"NASA · Asteroides y cometas","url":"https://cneos.jpl.nasa.gov/feed/news.xml","language":"en"},
    {"id":"incibe","category":"Ciberseguridad","title":"INCIBE · Avisos de seguridad","url":"https://www.incibe.es/feed/avisos-seguridad/all","language":"es"},
]
