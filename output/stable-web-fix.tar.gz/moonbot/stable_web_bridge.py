"""Read-only compatibility for the deployed Moonbot version and stable web."""
import hashlib
import hmac
import os
from collections import Counter

from flask import Blueprint, jsonify, request
from core.language_map import aggregate_language_map


def create_blueprint(db, get_bots, get_key=None):
    bp = Blueprint('stable_web_bridge', __name__)
    get_key = get_key or (lambda: os.environ.get('MOON_ADMIN_API_KEY', '').strip())

    @bp.get('/api/internal/admin-overview')
    def overview():
        expected = get_key()
        supplied = request.headers.get('X-Moon-Admin-Key', '')
        if not expected:
            return jsonify(ok=False, error='Integración interna no configurada'), 503
        if not hmac.compare_digest(supplied.encode(), expected.encode()):
            return jsonify(ok=False, error='No autorizado'), 401
        bots = list(get_bots())
        chat_sets = [set(str(cid) for cid in (db.get(f'CHATS_{bot.token}', []) or [])) for bot in bots]
        counts = Counter(cid for chats in chat_sets for cid in chats)
        instances = []
        for bot, chats in zip(bots, chat_sets):
            instances.append({
                'id': hashlib.sha256(bot.token.encode()).hexdigest()[:16],
                'username': getattr(bot, 'bot_username', ''),
                'status': 'loaded', 'groups': None, 'known_chats': len(chats),
                'shared_chats': sum(counts[cid] > 1 for cid in chats),
                'exclusive_chats': sum(counts[cid] == 1 for cid in chats),
                'latency_ms': None, 'updates_processed': None,
                'api_errors': None, 'uptime_seconds': None, 'poll_failures': None,
            })
        resources = {'cpu': None, 'ram': None, 'disk': None}
        try:
            import psutil
            resources.update(cpu=psutil.cpu_percent(interval=0.1),
                             ram=psutil.virtual_memory().percent,
                             disk=psutil.disk_usage('/').percent)
        except (ImportError, OSError):
            pass
        result = jsonify(ok=True, compatibility_mode=True,
            notice='Moonbot estable: bots cargados y recursos disponibles. Esta versión no mide conexión por bot, actividad de 24 horas, latencia ni errores. Las herramientas avanzadas requieren una actualización compatible.',
            summary={'instances_loaded': len(bots), 'instances_online': None,
                     'users_active_24h': None, 'groups': None,
                     'known_chats': len(counts), 'shared_groups': None},
            instances=instances, resources=resources, groups=[],
            services=[{'name': 'API Moonbot', 'status': 'online'}],
            pending={'total': None}, timeline=[])
        result.headers['Cache-Control'] = 'private, no-store'
        return result

    @bp.get('/api/public/stats/language-map')
    def language_map():
        stored = db.get('TELEGRAM_USER_LANGUAGES', {})
        stored = stored if isinstance(stored, dict) else {}
        payload = aggregate_language_map(stored)
        return jsonify(ok=True, **payload,
            notice=None if stored else 'Esta versión de Moonbot no tiene un historial de idiomas registrado. No se puede reconstruir a partir de los mensajes sin ese dato.')

    return bp
