"""Local Unix socket broker: inspect registered nodes, start/stop test worker only."""
import http.client
import http.server
import json
import os
import socket
import socketserver
import urllib.parse

SOCKET = '/run/moon-control/docker.sock'
NODES = {'moonbot', 'moonbot-helper-test'}
FLAGS = ('MOON_NODE_ID=', 'MOON_TRAFFIC_CONTROL_ENABLED=', 'MOON_TRAFFIC_BOOT_PAUSED=', 'MOON_TRAFFIC_DEFAULT_PAUSED=', 'TDLIB_API_ID=', 'TDLIB_API_HASH=')
class Engine(http.client.HTTPConnection):
    def connect(self):
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.settimeout(35)
        self.sock.connect('/var/run/docker.sock')
class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *args): pass
    def handle_request(self):
        parsed = urllib.parse.urlsplit(self.path)
        parts = parsed.path.split('/')
        valid = len(parts) == 4 and parts[1] == 'containers'
        name = urllib.parse.unquote(parts[2]) if valid else ''
        action = parts[3] if valid else ''
        read = self.command == 'GET' and name in NODES and action == 'json' and not parsed.query
        write = self.command == 'POST' and name == 'moonbot-helper-test' and ((action == 'start' and not parsed.query) or (action == 'stop' and parsed.query in ('t=15', 't=30')))
        if not (read or write):
            self.send_error(403, 'Operation not permitted'); return
        try:
            conn = Engine('localhost', timeout=35)
            conn.request(self.command, self.path)
            response = conn.getresponse(); body = response.read(2000000); status = response.status; conn.close()
            if read and status == 200:
                value = json.loads(body)
                cfg = value.get('Config') or {}
                flags = [entry for entry in cfg.get('Env', []) if entry.startswith(FLAGS)]
                # TDLib presence is sufficient for admission checks; never return its secrets.
                flags = [entry.split('=', 1)[0] + '=configured' if entry.startswith(('TDLIB_API_ID=', 'TDLIB_API_HASH=')) and entry.split('=',1)[1] else entry for entry in flags]
                state = {key:value.get('State',{}).get(key) for key in ('Running','Status','Restarting','OOMKilled')}
                if 'Health' in value.get('State',{}): state['Health'] = {'Status': value['State']['Health'].get('Status')}
                host = {key:value.get('HostConfig',{}).get(key) for key in ('Memory','NanoCpus','CpuQuota','CpuPeriod','PidsLimit')}
                body = json.dumps({'State':state,'Config':{'Image':cfg.get('Image'),'Env':flags},'HostConfig':host,'RestartCount':value.get('RestartCount')}).encode()
            self.send_response(status); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(body))); self.end_headers(); self.wfile.write(body)
        except Exception: self.send_error(502, 'Docker unavailable')
    do_GET = handle_request
    do_POST = handle_request
class Server(socketserver.ThreadingMixIn, socketserver.UnixStreamServer):
    daemon_threads = True
os.makedirs(os.path.dirname(SOCKET), mode=0o700, exist_ok=True)
if os.path.exists(SOCKET): os.unlink(SOCKET)
server = Server(SOCKET, Handler)
os.chmod(SOCKET, 0o600)
server.serve_forever()
